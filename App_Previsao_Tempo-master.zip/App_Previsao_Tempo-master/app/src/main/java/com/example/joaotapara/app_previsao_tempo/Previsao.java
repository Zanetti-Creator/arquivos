package com.example.joaotapara.app_previsao_tempo;

import javax.xml.transform.Result;

public class Previsao {

    Results results;

    public class Results{
        String temp;
        String description;
        String humidity;
        String date;
        String time;

    }
}
